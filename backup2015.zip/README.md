# MDT UFSM 2021

Alterações implementadas em comparação com o tamplate da MDT 2015:

1. Tamanho para nome e fonte de figuras reduz para 10pt
